<?php

namespace App\Services\PeopleConnect;

use App\Models\PeopleConnect\PeopleConnectSyncRun;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LiveMsgsSyncService
{
    protected string $wahaUrl;
    protected string $wahaSecret;
    
    public function __construct(
        protected PeopleConnectContactResolver $contactResolver,
        protected PeopleConnectConversationService $conversationService,
        protected PeopleConnectSessionService $sessionService,
        protected PeopleConnectMessageService $messageService
    ) {
        $this->wahaUrl = config('services.waha.url', 'http://waha:3000');
        $this->wahaSecret = config('services.waha.api_key', '');
    }

    public function syncContacts(): void
    {
        $run = PeopleConnectSyncRun::create([
            'type' => 'contacts',
            'status' => 'running',
            'started_at' => now(),
        ]);

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$this->wahaSecret}"
            ])->get("{$this->wahaUrl}/api/contacts/all?session=default");

            if ($response->successful()) {
                $contacts = $response->json();
                $count = 0;
                
                foreach ($contacts as $wahaContact) {
                    $id = $wahaContact['id'] ?? null;
                    if ($id && str_ends_with($id, '@c.us')) {
                        $phone = str_replace('@c.us', '', $id);
                        $this->contactResolver->resolve($id, $phone, $wahaContact['name'] ?? $wahaContact['pushname'] ?? '');
                        $count++;
                    }
                }
                
                $run->update([
                    'status' => 'completed',
                    'completed_at' => now(),
                    'contacts_found' => $count
                ]);
            } else {
                throw new \Exception('Failed to fetch contacts from WAHA: ' . $response->body());
            }
        } catch (\Throwable $e) {
            $run->update([
                'status' => 'failed',
                'completed_at' => now(),
                'errors' => ['message' => $e->getMessage()]
            ]);
        }
    }

    public function syncConversations(): void
    {
        $run = PeopleConnectSyncRun::create([
            'type' => 'conversations',
            'status' => 'running',
            'started_at' => now(),
        ]);

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$this->wahaSecret}"
            ])->get("{$this->wahaUrl}/api/chats?session=default");

            if ($response->successful()) {
                $chats = $response->json();
                $count = 0;
                
                foreach ($chats as $chat) {
                    $id = $chat['id'] ?? null;
                    if ($id && str_ends_with($id, '@c.us')) {
                        $phone = str_replace('@c.us', '', $id);
                        $contact = $this->contactResolver->resolve($id, $phone, $chat['name'] ?? '');
                        $this->conversationService->resolveOrCreate($contact->id, 'whatsapp', $id);
                        $count++;
                    }
                }
                
                $run->update([
                    'status' => 'completed',
                    'completed_at' => now(),
                    'conversations_found' => $count
                ]);
            } else {
                throw new \Exception('Failed to fetch conversations from WAHA: ' . $response->body());
            }
        } catch (\Throwable $e) {
            $run->update([
                'status' => 'failed',
                'completed_at' => now(),
                'errors' => ['message' => $e->getMessage()]
            ]);
        }
    }

    public function syncMessages(): void
    {
        // Simple stub for messages sync, real implementation would fetch history per chat
        $run = PeopleConnectSyncRun::create([
            'type' => 'messages',
            'status' => 'running',
            'started_at' => now(),
        ]);

        try {
            // Usually this requires paginating through chats and getting messages
            // Here we just mark complete for the stub
            $run->update([
                'status' => 'completed',
                'completed_at' => now(),
                'messages_found' => 0
            ]);
        } catch (\Throwable $e) {
            $run->update([
                'status' => 'failed',
                'completed_at' => now(),
                'errors' => ['message' => $e->getMessage()]
            ]);
        }
    }
}
