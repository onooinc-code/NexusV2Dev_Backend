<?php

namespace App\Services\HedraSoul;

use App\Models\SoulyRuntimeProfile;
use App\Models\SoulyActionPolicy;

/**
 * Value object representing an authorization policy decision.
 */
class PolicyResult
{
    public bool $allowed;
    public string $explanation;

    public function __construct(bool $allowed, string $explanation = '')
    {
        $this->allowed = $allowed;
        $this->explanation = $explanation;
    }
}

/**
 * SoulyActionPolicyService: Checks if an action is allowed based on autonomy mode and policy rules.
 * Enforces the 5 autonomy modes: chat_only, copilot, operator, autopilot_limited, emergency_paused.
 */
class SoulyActionPolicyService
{
    /**
     * Check if an action can execute given current autonomy mode and risk level.
     */
    public function canExecute(string $intent, string $riskLevel): PolicyResult
    {
        $profile = app(SoulyRuntimeProfileService::class)->getCurrent();

        // Emergency pause blocks all actions
        if ($profile->is_quarantined) {
            return new PolicyResult(false, 'Action blocked: Souly is quarantined');
        }

        if ($profile->autonomy_mode === 'emergency_paused') {
            return new PolicyResult(false, 'Action blocked: emergency_paused mode');
        }

        // Autonomy mode-specific enforcement
        switch ($profile->autonomy_mode) {
            case 'chat_only':
                // Only allow read-only actions
                if (!in_array($intent, ['answer', 'draft', 'notify'])) {
                    return new PolicyResult(
                        false,
                        "Action blocked: {$profile->autonomy_mode} mode allows only answer/draft"
                    );
                }
                break;

            case 'copilot':
                // Allow answers, drafts, task creation (preview), but block danger
                if ($intent === 'start_workflow' || $riskLevel === 'danger') {
                    return new PolicyResult(
                        false,
                        "Action blocked: {$profile->autonomy_mode} mode blocks workflows and danger actions"
                    );
                }
                break;

            case 'operator':
                // Allow most actions except danger and external sends
                if (in_array($riskLevel, ['external_send', 'danger'])) {
                    return new PolicyResult(
                        false,
                        "Action blocked: {$profile->autonomy_mode} mode blocks risk level {$riskLevel}"
                    );
                }
                break;

            case 'autopilot_limited':
                // Allow pre-approved workflows and low-risk actions
                if ($riskLevel === 'danger' || $intent === 'start_workflow') {
                    return new PolicyResult(
                        false,
                        "Action blocked: {$profile->autonomy_mode} mode requires pre-approval for workflows"
                    );
                }
                break;
        }

        // Check for mode-specific policy rules (overrides)
        $policy = SoulyActionPolicy::where('applies_to_mode', $profile->autonomy_mode)
            ->where('rule_key', $intent)
            ->first();

        if ($policy && $policy->rule_value === 'block') {
            return new PolicyResult(
                false,
                "Action blocked by policy rule for {$profile->autonomy_mode} mode"
            );
        }

        return new PolicyResult(true, 'Action permitted');
    }

    /**
     * Get current autonomy mode for introspection.
     */
    public function getCurrentMode(): string
    {
        return app(SoulyRuntimeProfileService::class)->getCurrent()->autonomy_mode;
    }

    /**
     * Check if Souly is quarantined.
     */
    public function isQuarantined(): bool
    {
        return app(SoulyRuntimeProfileService::class)->getCurrent()->is_quarantined;
    }
}
