<?php

namespace App\Services\HedraSoul;

use Illuminate\Support\Facades\Broadcast;

/**
 * HedraSoulRealtimeBroadcaster: Broadcasts all 13 HedraSoulHub realtime events to Reverb.
 * Each event is broadcast on the private channel hedrasoul.hub.{user_id}.
 */
class HedraSoulRealtimeBroadcaster
{
    /**
     * Broadcast message created event.
     */
    public function broadcastMessageCreated(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulMessageCreated($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast message created: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast message processed event.
     */
    public function broadcastMessageProcessed(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulMessageProcessed($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast message processed: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast command detected event.
     */
    public function broadcastCommandDetected(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulCommandDetected($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast command detected: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast command executed event.
     */
    public function broadcastCommandExecuted(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulCommandExecuted($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast command executed: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast approval requested event.
     */
    public function broadcastApprovalRequested(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulApprovalRequested($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast approval requested: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast approval approved event.
     */
    public function broadcastApprovalApproved(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulApprovalApproved($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast approval approved: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast approval rejected event.
     */
    public function broadcastApprovalRejected(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulApprovalRejected($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast approval rejected: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast instruction changed event.
     */
    public function broadcastInstructionChanged(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulInstructionChanged($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast instruction changed: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast model changed event.
     */
    public function broadcastModelChanged(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulModelChanged($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast model changed: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast memory suggested event.
     */
    public function broadcastMemorySuggested(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulMemorySuggested($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast memory suggested: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast memory approved event.
     */
    public function broadcastMemoryApproved(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulMemoryApproved($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast memory approved: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast autonomy changed event.
     */
    public function broadcastAutonomyChanged(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulAutonomyChanged($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast autonomy changed: ' . $e->getMessage());
        }
    }

    /**
     * Broadcast notification created event.
     */
    public function broadcastNotificationCreated(array $payload, int $userId): void
    {
        try {
            broadcast(new \App\Events\HedraSoul\HedraSoulNotificationCreated($payload, $userId))->toOthers();
        } catch (\Exception $e) {
            \Log::warning('Failed to broadcast notification created: ' . $e->getMessage());
        }
    }
}
