<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class HedrasoulSession extends Model
{
    protected $fillable = [
        'title',
        'status',
        'topic',
        'task_count',
        'approval_count',
        'instruction_version_id',
        'last_autonomy_mode',
        'opened_at',
        'closed_at',
        'summary',
    ];

    protected $casts = [
        'opened_at' => 'datetime',
        'closed_at' => 'datetime',
    ];

    public function messages()
    {
        return $this->hasMany(HedrasoulMessage::class, 'session_id');
    }

    public function instructionVersion()
    {
        return $this->belongsTo(SoulyInstructionVersion::class, 'instruction_version_id');
    }

    public function scopeActive(Builder $query)
    {
        return $query->where('status', 'active');
    }

    public function scopeArchived(Builder $query)
    {
        return $query->where('status', 'archived');
    }

    public function scopeClosed(Builder $query)
    {
        return $query->where('status', 'closed');
    }
}
