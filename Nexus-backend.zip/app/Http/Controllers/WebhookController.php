<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Services\PeopleConnect\WahaWebhookIngestionService;

class WebhookController extends Controller
{
    protected WahaWebhookIngestionService $ingestionService;

    public function __construct(WahaWebhookIngestionService $ingestionService)
    {
        $this->ingestionService = $ingestionService;
    }

    public function handleWahaWebhook(Request $request)
    {
        // 1. Validate shared-secret header
        $expectedSecret = config('services.waha.webhook_secret', env('WAHA_WEBHOOK_SECRET'));
        
        if ($expectedSecret) {
            // Check headers for typical WAHA secret headers or generic authorization
            $providedSecret = $request->header('x-waha-webhook-secret') 
                           ?? $request->header('authorization')
                           ?? $request->query('secret');
            
            // Basic matching (WAHA often sends it exactly as configured in their dashboard)
            if ($providedSecret !== $expectedSecret && $providedSecret !== "Bearer {$expectedSecret}") {
                Log::warning('WAHA Webhook rejected: Invalid secret', [
                    'ip' => $request->ip()
                ]);
                return response()->json(['message' => 'Unauthorized'], 401);
            }
        }

        // 2. Validate payload structure
        $validated = $request->validate([
            'event' => 'required|string',
            'session' => 'required|string',
            'payload' => 'required|array',
            'payload.id' => 'required_if:event,message|string',
            'payload.timestamp' => 'sometimes|integer',
            'payload.from' => 'sometimes|string',
            'payload.to' => 'sometimes|string',
            'payload.body' => 'sometimes|string',
        ]);

        // 3. Delegate to ingestion service
        try {
            $this->ingestionService->ingest($request->all());
            
            return response()->json([
                'message' => 'Webhook payload queued for processing'
            ], 202);
            
        } catch (\Exception $e) {
            Log::error('WAHA Webhook ingestion failed', [
                'error' => $e->getMessage(),
                'payload' => $request->all()
            ]);
            
            return response()->json([
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
}
