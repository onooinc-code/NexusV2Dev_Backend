<?php

namespace App\Events;

use App\Models\Contact;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ContactImportCompleted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

        public Contact $contact,
        public int $messagesImported,
        public string $source,
        public string $outcome = 'completed'
    ) {}
}
